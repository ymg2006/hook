<?php
if (!extension_loaded('openssl')) {
    die("The OpenSSL extension isn't loaded. Enable it in php.ini (extension=php_openssl.dll)\n");
}

// RSA is the default if you omit private_key_type.
$config = [
    'private_key_bits' => 2048,
    // If the constant exists, you can include it; otherwise omit.
    // 'private_key_type' => defined('OPENSSL_KEYTYPE_RSA') ? OPENSSL_KEYTYPE_RSA : OPENSSL_KEYTYPE_DEFAULT,
];

$keypair = openssl_pkey_new($config);
if (!$keypair) {
    die('Failed to generate keypair: ' . (openssl_error_string() ?: 'unknown error'));
}

// Export private key (PEM)
$private_key_pem = '';
if (!openssl_pkey_export($keypair, $private_key_pem)) {
    die('Failed to export private key: ' . (openssl_error_string() ?: 'unknown error'));
}

// Get public key (PEM)
$details = openssl_pkey_get_details($keypair);
if ($details === false || empty($details['key'])) {
    die('Failed to derive public key: ' . (openssl_error_string() ?: 'unknown error'));
}
$public_key_pem = $details['key'];

// Optional explicit free (not required on PHP 8+)
if (function_exists('openssl_pkey_free')) {
    openssl_pkey_free($keypair);
}

echo "Private Key:\n$private_key_pem\n\n";
echo "Public Key:\n$public_key_pem\n";
